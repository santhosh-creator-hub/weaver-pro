"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus,
  Mic,
  Package,
  TrendingUp,
  CalendarIcon,
  BarChart3,
  Users,
  Recycle,
  Trophy,
  AlertTriangle,
  QrCode,
  Target,
  Database,
  Trash2,
} from "lucide-react"
import { Bar, BarChart, Pie, PieChart, Cell, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts"

// Translations
const translations = {
  en: {
    appTitle: "Weaver Pro",
    appSubtitle: "Smart Production Tracking",
    logProduction: "Log Production",
    productType: "Product Type",
    fabricLength: "Fabric Length (meters)",
    timeTaken: "Time Taken (hours)",
    voiceNote: "Voice Note",
    addVoiceNote: "Add voice note...",
    recording: "Recording...",
    recentProduction: "Recent Production",
    weeklyProduction: "Weekly Production",
    yarnInventory: "Yarn Inventory",
    currentStockLevels: "Current stock levels",
    lowStockAlert: "Low stock alert!",
    scanQRToAddStock: "Scan QR to Add Stock",
    fabricWasteTracker: "Fabric Waste Tracker",
    totalWasteThisWeek: "Total Waste This Week",
    reuseSuggestions: "Reuse Suggestions:",
    monthlyGoal: "Monthly Goal",
    complete: "complete",
    remaining: "remaining",
    updateMonthlyGoal: "Update Monthly Goal",
    update: "Update",
    upcomingOrders: "Upcoming Orders",
    due: "Due",
    weeklyLeaderboard: "Weekly Leaderboard",
    thisWeek: "this week",
    yarnUsageDistribution: "Yarn Usage Distribution",
    efficiencyMetrics: "Efficiency Metrics",
    avgEfficiency: "Avg Efficiency (m/hr)",
    totalMeters: "Total Meters",
    dailyAverageIncome: "Daily Average Income",
    clusterOverview: "Cluster Overview",
    stock: "Stock",
    lowStock: "Low Stock",
    goodStock: "Good Stock",
    language: "Language",
    log: "Log",
    income: "Income",
    stats: "Stats",
    selectProduct: "Select product",
    noProductionLoggedToday: "No production logged today",
    lowStockWarning: "Low stock warning",
    pending: "pending",
    inProgress: "in-progress",
    completed: "completed",
    shipped: "shipped",
    cotton: "Cotton",
    silk: "Silk",
    wool: "Wool",
    useForPouches: "Use 150g for small pouches",
    createPatches: "Create decorative patches",
    makeCleaningCloths: "Make cleaning cloths",
    of: "of",
    goal: "goal",
    cottonSaree: "Cotton Saree",
    silkSaree: "Silk Saree",
    dupatta: "Dupatta",
    scarf: "Scarf",
    shawl: "Shawl",
    productPrice: "Product Price",
    orders: "Orders",
    submitOrder: "Submit Order",
    quantity: "Quantity",
    selectItems: "Select items to order",
    orderSuccess: "✅ Successfully submitted your order. Your order will be delivered within 45 minutes.",
    noItemsSelected: "Please select at least one item to order",
    submitting: "Submitting...",
    productManagement: "Product Management",
    addNewProduct: "Add New Product",
    productName: "Product Name",
    productCategory: "Product Category",
    price: "Price",
    stockQuantity: "Stock Quantity",
    addProduct: "Add Product",
    productList: "Product List",
    name: "Name",
    type: "Type",
    stockRemaining: "Stock Remaining",
    actions: "Actions",
    remove: "Remove",
    productAdded: "Product added successfully!",
    productRemoved: "Product removed successfully!",
    enterProductName: "Enter product name",
    selectCategory: "Select category",
    enterPrice: "Enter price",
    enterStock: "Enter stock quantity",
    database: "Database",
    saree: "Saree",
    fabric: "Fabric",
    accessory: "Accessory",
    clothing: "Clothing",
    homeTextile: "Home Textile",
    other: "Other",
    orderId: "Order ID",
    enterOrderId: "Enter order ID",
    orderSubmittedSuccess: "Order {orderId} submitted successfully! Your order will be delivered within 45 minutes.",
    noOrderId: "Please enter an order ID",
    orderGroup: "Order Group",
    stockOrdering: "Stock Ordering",
    restockMaterials: "Restock Materials",
    fabrics: "Fabrics",
    threads: "Threads",
    accessories: "Accessories",
    decorItems: "Decor Items",
    machineParts: "Machine Parts",
    selectItem: "Select item",
    units: "units",
    reels: "reels",
    pieces: "pieces",
    meters: "meters",
    submitStockOrder: "Submit Stock Order",
    stockOrderSuccess: "Your stock order has been taken. It will be delivered within 45 minutes.",
    noItemsSelectedForStock: "Please select at least one item to order",
    submittingStockOrder: "Submitting stock order...",
    outOfStock: "Out of Stock",
    lowStock: "Low Stock",
    inStock: "In Stock",
    viewPastOrders: "View Past Orders",
    deliveryEta: "Delivery ETA",
    minutes: "minutes",
    stockAlert: "Stock Alert",
    suggestRestock: "Suggest Restock",
    cotton: "Cotton",
    silk: "Silk",
    wool: "Wool",
    polyester: "Polyester",
    linen: "Linen",
    nylon: "Nylon",
    buttons: "Buttons",
    zippers: "Zippers",
    hooks: "Hooks",
    velcro: "Velcro",
    lace: "Lace",
    beads: "Beads",
    ribbons: "Ribbons",
    patches: "Patches",
    spoolPin: "Spool Pin",
    bobbin: "Bobbin",
    needle: "Needle",
    presserFoot: "Presser Foot",
    handWheel: "Hand Wheel",
    unit: "unit",
    reel: "reel",
    piece: "piece",
    meter: "meter",
  },
  ta: {
    appTitle: "நெசவாளர் புரோ",
    appSubtitle: "ஸ்மார்ட் உற்பத்தி கண்காணிப்பு",
    logProduction: "உற்பத்தி பதிவு செய்",
    productType: "தயாரிப்பு வகை",
    fabricLength: "துணி நீளம் (மீட்டர்)",
    timeTaken: "எடுத்த நேரம் (மணி)",
    voiceNote: "குரல் குறிப்பு",
    addVoiceNote: "குரல் குறிப்பு சேர்க்கவும்...",
    recording: "பதிவு செய்கிறது...",
    recentProduction: "சமீபத்திய உற்பத்தி",
    weeklyProduction: "வாராந்திர உற்பத்தி",
    yarnInventory: "நூல் கையிருப்பு",
    currentStockLevels: "தற்போதைய கையிருப்பு நிலைகள்",
    lowStockAlert: "குறைந்த கையிருப்பு எச்சரிக்கை!",
    scanQRToAddStock: "கையிருப்பு சேர்க்க QR ஸ்கேன் செய்யவும்",
    fabricWasteTracker: "துணி கழிவு கண்காணிப்பு",
    totalWasteThisWeek: "இந்த வாரம் மொத்த கழிவு",
    reuseSuggestions: "மறுபயன்பாட்டு பரிந்துரைகள்:",
    monthlyGoal: "மாதாந்திர இலக்கு",
    complete: "முடிந்தது",
    remaining: "மீதமுள்ளது",
    updateMonthlyGoal: "மாதாந்திர இலக்கை புதுப்பிக்கவும்",
    update: "புதுப்பிக்கவும்",
    upcomingOrders: "வரவிருக்கும் ஆர்டர்கள்",
    due: "முடிவு",
    weeklyLeaderboard: "வாராந்திர முன்னணி பட்டியல்",
    thisWeek: "இந்த வாரம்",
    yarnUsageDistribution: "நூல் பயன்பாட்டு விநியோகம்",
    efficiencyMetrics: "செயல்திறன் அளவீடுகள்",
    avgEfficiency: "சராசரி செயல்திறன் (மீ/மணி)",
    totalMeters: "மொத்த மீட்டர்கள்",
    dailyAverageIncome: "தினசரி சராசரி வருமானம்",
    clusterOverview: "கிளஸ்டர் கண்ணோட்டம்",
    stock: "கையிருப்பு",
    lowStock: "குறைந்த கையிருப்பு",
    goodStock: "நல்ல கையிருப்பு",
    language: "மொழி",
    log: "பதிவு",
    income: "வருமானம்",
    stats: "புள்ளிவிவரம்",
    selectProduct: "தயாரிப்பு தேர்ந்தெடுக்கவும்",
    noProductionLoggedToday: "இன்று உற்பத்தி பதிவு செய்யப்படவில்லை",
    lowStockWarning: "குறைந்த கையிருப்பு எச்சரிக்கை",
    pending: "நிலுவையில்",
    inProgress: "செயலில்",
    completed: "முடிந்தது",
    shipped: "அனுப்பப்பட்டது",
    cotton: "பருத்தி",
    silk: "பட்டு",
    wool: "கம்பளி",
    useForPouches: "சிறிய பைகளுக்கு 150கி பயன்படுத்தவும்",
    createPatches: "அலங்கார ஒட்டுகள் உருவாக்கவும்",
    makeCleaningCloths: "சுத்தம் செய்யும் துணிகள் செய்யவும்",
    of: "இன்",
    goal: "இலக்கு",
    cottonSaree: "பருத்தி சேலை",
    silkSaree: "பட்டு சேலை",
    dupatta: "துப்பட்டா",
    scarf: "ஸ்கார்ஃப்",
    shawl: "சால்வை",
    productPrice: "தயாரிப்பு விலை",
    orders: "ஆர்டர்கள்",
    submitOrder: "ஆர்டர் சமர்ப்பிக்கவும்",
    quantity: "அளவு",
    selectItems: "ஆர்டர் செய்ய பொருட்களை தேர்ந்தெடுக்கவும்",
    orderSuccess: "✅ உங்கள் ஆர்டர் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது. உங்கள் ஆர்டர் 45 நிமிடங்களில் வழங்கப்படும்.",
    noItemsSelected: "ஆர்டர் செய்ய குறைந்தது ஒரு பொருளையாவது தேர்ந்தெடுக்கவும்",
    submitting: "சமர்ப்பிக்கிறது...",
    productManagement: "தயாரிப்பு மேலாண்மை",
    addNewProduct: "புதிய தயாரிப்பு சேர்க்கவும்",
    productName: "தயாரிப்பு பெயர்",
    productCategory: "தயாரிப்பு வகை",
    price: "விலை",
    stockQuantity: "கையிருப்பு அளவு",
    addProduct: "தயாரிப்பு சேர்க்கவும்",
    productList: "தயாரிப்பு பட்டியல்",
    name: "பெயர்",
    type: "வகை",
    stockRemaining: "மீதமுள்ள கையிருப்பு",
    actions: "செயல்கள்",
    remove: "அகற்று",
    productAdded: "தயாரிப்பு வெற்றிகரமாக சேர்க்கப்பட்டது!",
    productRemoved: "தயாரிப்பு வெற்றிகரமாக அகற்றப்பட்டது!",
    enterProductName: "தயாரிப்பு பெயரை உள்ளிடவும்",
    selectCategory: "வகையை தேர்ந்தெடுக்கவும்",
    enterPrice: "விலையை உள்ளிடவும்",
    enterStock: "கையிருப்பு அளவை உள்ளிடவும்",
    database: "தரவுத்தளம்",
    saree: "சேலை",
    fabric: "துணி",
    accessory: "துணைப்பொருள்",
    clothing: "உடை",
    homeTextile: "வீட்டு துணி",
    other: "மற்றவை",
    orderId: "ஆர்டர் ஐடி",
    enterOrderId: "ஆர்டர் ஐடி உள்ளிடவும்",
    orderSubmittedSuccess: "ஆர்டர் {orderId} வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது! உங்கள் ஆர்டர் 45 நிமிடங்களில் வழங்கப்படும்.",
    noOrderId: "தயவுசெய்து ஆர்டர் ஐடி உள்ளிடவும்",
    orderGroup: "ஆர்டர் குழு",
    stockOrdering: "கையிருப்பு ஆர்டர்",
    restockMaterials: "பொருட்களை மீண்டும் நிரப்பவும்",
    fabrics: "துணிகள்",
    threads: "நூல்கள்",
    accessories: "துணைப்பொருட்கள்",
    decorItems: "அலங்கார பொருட்கள்",
    machineParts: "இயந்திர பாகங்கள்",
    selectItem: "பொருள் தேர்ந்தெடுக்கவும்",
    units: "அலகுகள்",
    reels: "ரீல்கள்",
    pieces: "துண்டுகள்",
    meters: "மீட்டர்கள்",
    submitStockOrder: "கையிருப்பு ஆர்டர் சமர்ப்பிக்கவும்",
    stockOrderSuccess: "உங்கள் கையிருப்பு ஆர்டர் எடுக்கப்பட்டது. இது 45 நிமிடங்களில் வழங்கப்படும்.",
    noItemsSelectedForStock: "ஆர்டர் செய்ய குறைந்தது ஒரு பொருளையாவது தேர்ந்தெடுக்கவும்",
    submittingStockOrder: "கையிருப்பு ஆர்டர் சமர்ப்பிக்கிறது...",
    outOfStock: "கையிருப்பு இல்லை",
    lowStock: "குறைந்த கையிருப்பு",
    inStock: "கையிருப்பில் உள்ளது",
    viewPastOrders: "கடந்த ஆர்டர்களை பார்க்கவும்",
    deliveryEta: "டெலிவரி ETA",
    minutes: "நிமிடங்கள்",
    stockAlert: "கையிருப்பு எச்சரிக்கை",
    suggestRestock: "மீண்டும் நிரப்ப பரிந்துரை",
    cotton: "பருத்தி",
    silk: "பட்டு",
    wool: "கம்பளி",
    polyester: "பாலியஸ்டர்",
    linen: "லினன்",
    nylon: "நைலான்",
    buttons: "பொத்தான்கள்",
    zippers: "ஜிப்பர்கள்",
    hooks: "கொக்கிகள்",
    velcro: "வெல்க்ரோ",
    lace: "லேஸ்",
    beads: "மணிகள்",
    ribbons: "ரிப்பன்கள்",
    patches: "ஒட்டுகள்",
    spoolPin: "ஸ்பூல் பின்",
    bobbin: "பாபின்",
    needle: "ஊசி",
    presserFoot: "பிரஸ்ஸர் ஃபுட்",
    handWheel: "கை சக்கரம்",
    unit: "அலகு",
    reel: "ரீல்",
    piece: "துண்டு",
    meter: "மீட்டர்",
  },
  hi: {
    appTitle: "वीवर प्रो",
    appSubtitle: "स्मार्ट उत्पादन ट्रैकिंग",
    logProduction: "उत्पादन दर्ज करें",
    productType: "उत्पाद प्रकार",
    fabricLength: "कपड़े की लंबाई (मीटर)",
    timeTaken: "समय लिया (घंटे)",
    voiceNote: "वॉइस नोट",
    addVoiceNote: "वॉइस नोट जोड़ें...",
    recording: "रिकॉर्डिंग...",
    recentProduction: "हाल का उत्पादन",
    weeklyProduction: "साप्ताहिक उत्पादन",
    yarnInventory: "धागा भंडार",
    currentStockLevels: "वर्तमान स्टॉक स्तर",
    lowStockAlert: "कम स्टॉक अलर्ट!",
    scanQRToAddStock: "स्टॉक जोड़ने के लिए QR स्कैन करें",
    fabricWasteTracker: "कपड़ा अपशिष्ट ट्रैकर",
    totalWasteThisWeek: "इस सप्ताह कुल अपशिष्ट",
    reuseSuggestions: "पुन: उपयोग सुझाव:",
    monthlyGoal: "मासिक लक्ष्य",
    complete: "पूर्ण",
    remaining: "शेष",
    updateMonthlyGoal: "मासिक लक्ष्य अपडेट करें",
    update: "अपडेट करें",
    upcomingOrders: "आगामी ऑर्डर",
    due: "देय",
    weeklyLeaderboard: "साप्ताहिक लीडरबोर्ड",
    thisWeek: "इस सप्ताह",
    yarnUsageDistribution: "धागा उपयोग वितरण",
    efficiencyMetrics: "दक्षता मेट्रिक्स",
    avgEfficiency: "औसत दक्षता (मी/घंटा)",
    totalMeters: "कुल मीटर",
    dailyAverageIncome: "दैनिक औसत आय",
    clusterOverview: "क्लस्टर अवलोकन",
    stock: "स्टॉक",
    lowStock: "कम स्टॉक",
    goodStock: "अच्छा स्टॉक",
    language: "भाषा",
    log: "लॉग",
    income: "आय",
    stats: "आंकड़े",
    selectProduct: "उत्पाद चुनें",
    noProductionLoggedToday: "आज कोई उत्पादन दर्ज नहीं किया गया",
    lowStockWarning: "कम स्टॉक चेतावनी",
    pending: "लंबित",
    inProgress: "प्रगति में",
    completed: "पूर्ण",
    shipped: "भेजा गया",
    cotton: "कपास",
    silk: "रेशम",
    wool: "ऊन",
    useForPouches: "छोटे पाउच के लिए 150ग्राम का उपयोग करें",
    createPatches: "सजावटी पैच बनाएं",
    makeCleaningCloths: "सफाई के कपड़े बनाएं",
    of: "का",
    goal: "लक्ष्य",
    cottonSaree: "कॉटन साड़ी",
    silkSaree: "सिल्क साड़ी",
    dupatta: "दुपट्टा",
    scarf: "स्कार्फ",
    shawl: "शॉल",
    productPrice: "उत्पाद मूल्य",
    orders: "ऑर्डर",
    submitOrder: "ऑर्डर सबमिट करें",
    quantity: "मात्रा",
    selectItems: "ऑर्डर के लिए आइटम चुनें",
    orderSuccess: "✅ आपका ऑर्डर सफलतापूर्वक सबमिट हो गया। आपका ऑर्डर 45 मिनट में डिलीवर हो जाएगा।",
    noItemsSelected: "कृपया ऑर्डर करने के लिए कम से कम एक आइटम चुनें",
    submitting: "सबमिट कर रहे हैं...",
    productManagement: "उत्पाद प्रबंधन",
    addNewProduct: "नया उत्पाद जोड़ें",
    productName: "उत्पाद नाम",
    productCategory: "उत्पाद श्रेणी",
    price: "मूल्य",
    stockQuantity: "स्टॉक मात्रा",
    addProduct: "उत्पाद जोड़ें",
    productList: "उत्पाद सूची",
    name: "नाम",
    type: "प्रकार",
    stockRemaining: "शेष स्टॉक",
    actions: "कार्य",
    remove: "हटाएं",
    productAdded: "उत्पाद सफलतापूर्वक जोड़ा गया!",
    productRemoved: "उत्पाद सफलतापूर्वक हटाया गया!",
    enterProductName: "उत्पाद नाम दर्ज करें",
    selectCategory: "श्रेणी चुनें",
    enterPrice: "मूल्य दर्ज करें",
    enterStock: "स्टॉक मात्रा दर्ज करें",
    database: "डेटाबेस",
    saree: "साड़ी",
    fabric: "कपड़ा",
    accessory: "सहायक",
    clothing: "कपड़े",
    homeTextile: "घरेलू वस्त्र",
    other: "अन्य",
    orderId: "ऑर्डर आईडी",
    enterOrderId: "ऑर्डर आईडी दर्ज करें",
    orderSubmittedSuccess: "ऑर्डर {orderId} सफलतापूर्वक सबमिट हो गया! आपका ऑर्डर 45 मिनट में डिलीवर हो जाएगा।",
    noOrderId: "कृपया ऑर्डर आईडी दर्ज करें",
    orderGroup: "ऑर्डर समूह",
    stockOrdering: "स्टॉक ऑर्डरिंग",
    restockMaterials: "सामग्री फिर से भरें",
    fabrics: "कपड़े",
    threads: "धागे",
    accessories: "सहायक उपकरण",
    decorItems: "सजावटी वस्तुएं",
    machineParts: "मशीन के पुर्जे",
    selectItem: "आइटम चुनें",
    units: "इकाइयां",
    reels: "रीलें",
    pieces: "टुकड़े",
    meters: "मीटर",
    submitStockOrder: "स्टॉक ऑर्डर सबमिट करें",
    stockOrderSuccess: "आपका स्टॉक ऑर्डर लिया गया है। यह 45 मिनट में डिलीवर हो जाएगा।",
    noItemsSelectedForStock: "कृपया ऑर्डर करने के लिए कम से कम एक आइटम चुनें",
    submittingStockOrder: "स्टॉक ऑर्डर सबमिट कर रहे हैं...",
    outOfStock: "स्टॉक खत्म",
    lowStock: "कम स्टॉक",
    inStock: "स्टॉक में",
    viewPastOrders: "पिछले ऑर्डर देखें",
    deliveryEta: "डिलीवरी ETA",
    minutes: "मिनट",
    stockAlert: "स्टॉक अलर्ट",
    suggestRestock: "रीस्टॉक सुझाएं",
    cotton: "कपास",
    silk: "रेशम",
    wool: "ऊन",
    polyester: "पॉलिएस्टर",
    linen: "लिनन",
    nylon: "नायलॉन",
    buttons: "बटन",
    zippers: "जिपर",
    hooks: "हुक",
    velcro: "वेल्क्रो",
    lace: "लेस",
    beads: "मोती",
    ribbons: "रिबन",
    patches: "पैच",
    spoolPin: "स्पूल पिन",
    bobbin: "बॉबिन",
    needle: "सुई",
    presserFoot: "प्रेसर फुट",
    handWheel: "हैंड व्हील",
    unit: "इकाई",
    reel: "रील",
    piece: "टुकड़ा",
    meter: "मीटर",
  },
}

// Price generation function
const generateRandomPrice = (min: number, max: number): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Generate random prices for all items on component load
const generateItemPrices = (): Record<string, { price: number; unit: string }> => {
  const priceRanges = {
    // Fabrics: ₹100-500/unit
    Cotton: { min: 100, max: 500, unit: "unit" },
    Silk: { min: 100, max: 500, unit: "unit" },
    Wool: { min: 100, max: 500, unit: "unit" },
    Polyester: { min: 100, max: 500, unit: "unit" },
    Linen: { min: 100, max: 500, unit: "unit" },
    Nylon: { min: 100, max: 500, unit: "unit" },

    // Threads: ₹50-150/reel
    "Cotton Thread": { min: 50, max: 150, unit: "reel" },
    "Polyester Thread": { min: 50, max: 150, unit: "reel" },
    "Silk Thread": { min: 50, max: 150, unit: "reel" },
    "Nylon Thread": { min: 50, max: 150, unit: "reel" },

    // Accessories: ₹1-10/piece
    Buttons: { min: 1, max: 10, unit: "piece" },
    Zippers: { min: 1, max: 10, unit: "piece" },
    Hooks: { min: 1, max: 10, unit: "piece" },
    Velcro: { min: 1, max: 10, unit: "piece" },

    // Decor Items: ₹10-100/piece
    Lace: { min: 10, max: 100, unit: "piece" },
    Beads: { min: 10, max: 100, unit: "piece" },
    Ribbons: { min: 10, max: 100, unit: "piece" },
    Patches: { min: 10, max: 100, unit: "piece" },

    // Machine Parts: ₹50-300/part
    "Spool Pin": { min: 50, max: 300, unit: "part" },
    Bobbin: { min: 50, max: 300, unit: "part" },
    Needle: { min: 50, max: 300, unit: "part" },
    "Presser Foot": { min: 50, max: 300, unit: "part" },
    "Hand Wheel": { min: 50, max: 300, unit: "part" },
  }

  const itemPrices: Record<string, { price: number; unit: string }> = {}

  Object.entries(priceRanges).forEach(([item, range]) => {
    itemPrices[item] = {
      price: generateRandomPrice(range.min, range.max),
      unit: range.unit,
    }
  })

  return itemPrices
}

// Mock data types
interface ProductionLog {
  id: string
  date: string
  orderId: string
  productType: string
  fabricLength: number
  timeTaken: number
  efficiency: number
  voiceNote?: string
}

interface YarnStock {
  cotton: number
  silk: number
  wool: number
}

interface Order {
  id: string
  product: string
  deadline: string
  status: "pending" | "in-progress" | "completed" | "shipped"
  customer: string
}

interface Product {
  id: number
  name: string
  type: string
  price: number
  stock: number
}

interface StockItem {
  id: number
  category: string
  item: string
  price: number
  unit: string
  status: "outOfStock" | "lowStock" | "inStock"
  currentStock: number
}

interface StockOrder {
  category: string
  item: string
  quantity: number
  selected: boolean
}

const mockStockItems: StockItem[] = [
  { id: 1, category: "Fabrics", item: "Silk", price: 250, unit: "unit", status: "outOfStock", currentStock: 0 },
  { id: 2, category: "Fabrics", item: "Cotton", price: 150, unit: "unit", status: "lowStock", currentStock: 2 },
  { id: 3, category: "Threads", item: "Polyester", price: 80, unit: "reel", status: "outOfStock", currentStock: 0 },
  { id: 4, category: "Accessories", item: "Hooks", price: 2, unit: "piece", status: "lowStock", currentStock: 15 },
  { id: 5, category: "Decor Items", item: "Lace", price: 45, unit: "meter", status: "inStock", currentStock: 50 },
  { id: 6, category: "Machine Parts", item: "Needle", price: 25, unit: "piece", status: "outOfStock", currentStock: 0 },
]

const stockCategories = {
  Fabrics: ["Cotton", "Silk", "Wool", "Polyester", "Linen", "Nylon"],
  Threads: ["Cotton Thread", "Polyester Thread", "Silk Thread", "Nylon Thread"],
  Accessories: ["Buttons", "Zippers", "Hooks", "Velcro"],
  "Decor Items": ["Lace", "Beads", "Ribbons", "Patches"],
  "Machine Parts": ["Spool Pin", "Bobbin", "Needle", "Presser Foot", "Hand Wheel"],
}

const mockOrderGroups = [
  {
    orderId: "ORD001",
    items: [
      { id: 1, name: "Cotton Saree", description: "Premium quality cotton saree", price: 1000 },
      { id: 2, name: "Silk Dupatta", description: "Elegant silk dupatta with border", price: 800 },
      { id: 3, name: "Handwoven Scarf", description: "Artisan crafted handwoven scarf", price: 300 },
    ],
  },
  {
    orderId: "ORD002",
    items: [
      { id: 4, name: "Cotton Kurti Fabric", description: "Soft cotton fabric for kurti", price: 400 },
      { id: 5, name: "Silk Saree", description: "Luxurious silk saree collection", price: 2500 },
    ],
  },
  {
    orderId: "ORD003",
    items: [
      {
        id: 6,
        name: "Linen Dupatta",
        description: "Breathable linen dupatta",
        price: 600,
      },
      {
        id: 7,
        name: "Woolen Shawl",
        description: "Warm woolen shawl for winter",
        price: 1200,
      },
      {
        id: 8,
        name: "Cotton Mask Set",
        description: "Reusable cotton face masks",
        price: 150,
      },
    ],
  },
  {
    orderId: "ORD004",
    items: [
      {
        id: 9,
        name: "Silk Blend Saree",
        description: "Beautiful silk blend saree",
        price: 1800,
      },
      {
        id: 10,
        name: "Kids Cotton Wear",
        description: "Comfortable cotton wear for kids",
        price: 350,
      },
      {
        id: 11,
        name: "Pouch Fabric Scrap",
        description: "Fabric scraps for small pouches",
        price: 100,
      },
    ],
  },
  {
    orderId: "ORD005",
    items: [
      {
        id: 12,
        name: "Organic Cotton Scarf",
        description: "Eco-friendly organic cotton scarf",
        price: 450,
      },
      {
        id: 13,
        name: "Sustainable Tote Bag",
        description: "Eco-friendly reusable tote bag",
        price: 250,
      },
      {
        id: 14,
        name: "Soft Towel Set",
        description: "Absorbent cotton towel set",
        price: 800,
      },
      {
        id: 15,
        name: "Designer Border Roll",
        description: "Decorative border fabric roll",
        price: 200,
      },
    ],
  },
]

interface Weaver {
  id: string
  name: string
  weeklyOutput: number
  stockLeft: number
  badges: string[]
}

export default function WeaverApp() {
  // Language state
  const [lang, setLang] = useState<"en" | "ta" | "hi">("en")

  // Helper function to get translation
  const t = (key: keyof typeof translations.en) => translations[lang][key]

  // Get product prices based on current language
  const getProductPrices = () => ({
    [t("cottonSaree")]: 1000,
    [t("silkSaree")]: 2500,
    [t("dupatta")]: 500,
    [t("scarf")]: 300,
    [t("shawl")]: 800,
  })

  const productTypes = Object.keys(getProductPrices())

  // Product categories
  const productCategories = [t("saree"), t("fabric"), t("accessory"), t("clothing"), t("homeTextile"), t("other")]

  // State management
  const [activeTab, setActiveTab] = useState("production")
  const [productionLogs, setProductionLogs] = useState<ProductionLog[]>([
    {
      id: "1",
      date: "2024-01-15",
      orderId: "ORD001",
      productType: "Cotton Saree",
      fabricLength: 6,
      timeTaken: 8,
      efficiency: 0.75,
      voiceNote: "Good quality cotton, smooth weaving",
    },
    {
      id: "2",
      date: "2024-01-14",
      orderId: "ORD002",
      productType: "Dupatta",
      fabricLength: 2.5,
      timeTaken: 3,
      efficiency: 0.83,
    },
  ])

  const [yarnStock, setYarnStock] = useState<YarnStock>({
    cotton: 1500,
    silk: 1000,
    wool: 800,
  })

  const [monthlyGoal, setMonthlyGoal] = useState(10000)
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "1",
      product: "Cotton Saree",
      deadline: "2024-01-20",
      status: "in-progress",
      customer: "Priya Sharma",
    },
    {
      id: "2",
      product: "Silk Saree",
      deadline: "2024-01-25",
      status: "pending",
      customer: "Anita Devi",
    },
  ])

  const [weavers] = useState<Weaver[]>([
    { id: "1", name: "Kamala Devi", weeklyOutput: 15, stockLeft: 500, badges: ["10-Day Streak"] },
    { id: "2", name: "Sunita Sharma", weeklyOutput: 12, stockLeft: 300, badges: ["Zero Waste Champ"] },
    { id: "3", name: "Meera Patel", weeklyOutput: 18, stockLeft: 700, badges: ["Speed Weaver"] },
  ])

  const [selectedOrderItems, setSelectedOrderItems] = useState<
    Record<string, Record<number, { checked: boolean; quantity: number }>>
  >({})
  const [isSubmittingOrders, setIsSubmittingOrders] = useState<Record<string, boolean>>({})
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({})

  // Product Management State
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: "Cotton Saree", type: "Saree", price: 1000, stock: 25 },
    { id: 2, name: "Silk Dupatta", type: "Accessory", price: 800, stock: 15 },
    { id: 3, name: "Handwoven Scarf", type: "Accessory", price: 300, stock: 30 },
    { id: 4, name: "Cotton Kurti Fabric", type: "Fabric", price: 400, stock: 50 },
    { id: 5, name: "Silk Saree", type: "Saree", price: 2500, stock: 10 },
  ])

  const [newProduct, setNewProduct] = useState({
    name: "",
    type: "",
    price: "",
    stock: "",
  })

  // Form states
  const [newLog, setNewLog] = useState({
    orderId: "",
    productType: "",
    fabricLength: "",
    timeTaken: "",
    voiceNote: "",
  })

  const [isRecording, setIsRecording] = useState(false)
  const [alerts, setAlerts] = useState<string[]>([])

  // Stock Ordering State with random prices
  const [itemPrices] = useState(() => generateItemPrices())

  // Stock Ordering State
  const [stockOrders, setStockOrders] = useState<StockOrder[]>([
    { category: "Fabrics", item: "", quantity: 1, selected: false },
    { category: "Threads", item: "", quantity: 1, selected: false },
    { category: "Accessories", item: "", quantity: 1, selected: false },
    { category: "Decor Items", item: "", quantity: 1, selected: false },
    { category: "Machine Parts", item: "", quantity: 1, selected: false },
  ])
  const [isSubmittingStockOrder, setIsSubmittingStockOrder] = useState(false)
  const [pastStockOrders, setPastStockOrders] = useState<any[]>([])
  const [deliveryCountdown, setDeliveryCountdown] = useState<number | null>(null)

  // Load language from localStorage on component mount
  useEffect(() => {
    const savedLang = localStorage.getItem("weaver-app-language") as "en" | "ta" | "hi"
    if (savedLang && ["en", "ta", "hi"].includes(savedLang)) {
      setLang(savedLang)
    }
  }, [])

  // Save language to localStorage when changed
  const handleLanguageChange = (newLang: "en" | "ta" | "hi") => {
    setLang(newLang)
    localStorage.setItem("weaver-app-language", newLang)
  }

  // Product Management Functions
  const addProduct = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newProduct.name || !newProduct.type || !newProduct.price || !newProduct.stock) return

    const product: Product = {
      id: Date.now(),
      name: newProduct.name,
      type: newProduct.type,
      price: Number.parseFloat(newProduct.price),
      stock: Number.parseInt(newProduct.stock),
    }

    setProducts([...products, product])
    setNewProduct({ name: "", type: "", price: "", stock: "" })
    alert(t("productAdded"))
  }

  const removeProduct = (id: number) => {
    setProducts(products.filter((product) => product.id !== id))
    alert(t("productRemoved"))
  }

  const updateOrderSelection = (orderId: string, itemId: number, updates: { checked?: boolean; quantity?: number }) => {
    setSelectedOrderItems((prev) => ({
      ...prev,
      [orderId]: {
        ...prev[orderId],
        [itemId]: {
          checked: updates.checked !== undefined ? updates.checked : prev[orderId]?.[itemId]?.checked || false,
          quantity: updates.quantity !== undefined ? updates.quantity : prev[orderId]?.[itemId]?.quantity || 1,
        },
      },
    }))
  }

  const handleOrderSubmit = async (orderId: string) => {
    const orderItems = selectedOrderItems[orderId] || {}
    const selectedCount = Object.values(orderItems).filter((item) => item.checked).length

    if (selectedCount === 0) {
      alert(t("noItemsSelected"))
      return
    }

    setIsSubmittingOrders((prev) => ({ ...prev, [orderId]: true }))

    // Simulate API call
    setTimeout(() => {
      const successMessage = t("orderSubmittedSuccess").replace("{orderId}", orderId)
      alert(successMessage)
      setSelectedOrderItems((prev) => ({ ...prev, [orderId]: {} }))
      setIsSubmittingOrders((prev) => ({ ...prev, [orderId]: false }))
    }, 1500)
  }

  const getTotalSelectedItemsForOrder = (orderId: string) => {
    const orderItems = selectedOrderItems[orderId] || {}
    return Object.values(orderItems).filter((item) => item.checked).length
  }

  const toggleOrderExpansion = (orderId: string) => {
    setExpandedOrders((prev) => ({ ...prev, [orderId]: !prev[orderId] }))
  }

  // Stock Ordering Functions
  const updateStockOrder = (category: string, updates: Partial<StockOrder>) => {
    setStockOrders((prev) => prev.map((order) => (order.category === category ? { ...order, ...updates } : order)))
  }

  const getItemPrice = (category: string, item: string) => {
    return itemPrices[item]?.price || 0
  }

  const getItemUnit = (category: string, item: string) => {
    const unit = itemPrices[item]?.unit || "unit"
    return t(unit as keyof typeof translations.en)
  }

  const getItemStatus = (category: string, item: string) => {
    const stockItem = mockStockItems.find((stock) => stock.category === category && stock.item === item)
    return stockItem ? stockItem.status : "inStock"
  }

  const handleStockOrderSubmit = async () => {
    const selectedOrders = stockOrders.filter((order) => order.selected && order.item)

    if (selectedOrders.length === 0) {
      alert(t("noItemsSelectedForStock"))
      return
    }

    setIsSubmittingStockOrder(true)

    // Simulate API call
    setTimeout(() => {
      alert(t("stockOrderSuccess"))

      // Add to past orders
      const newOrder = {
        id: Date.now(),
        items: selectedOrders,
        timestamp: new Date().toISOString(),
        status: "pending",
      }
      setPastStockOrders((prev) => [newOrder, ...prev])

      // Start delivery countdown
      setDeliveryCountdown(45)

      // Reset form
      setStockOrders((prev) => prev.map((order) => ({ ...order, selected: false, item: "", quantity: 1 })))

      setIsSubmittingStockOrder(false)
    }, 1500)
  }

  const getSelectedStockCount = () => {
    return stockOrders.filter((order) => order.selected && order.item).length
  }

  // Chart data
  const weeklyData = [
    { day: "Mon", meters: 8 },
    { day: "Tue", meters: 12 },
    { day: "Wed", meters: 6 },
    { day: "Thu", meters: 15 },
    { day: "Fri", meters: 10 },
    { day: "Sat", meters: 14 },
    { day: "Sun", meters: 9 },
  ]

  const yarnUsageData = [
    { name: t("cotton"), value: 60, color: "#8884d8" },
    { name: t("silk"), value: 30, color: "#82ca9d" },
    { name: t("wool"), value: 10, color: "#ffc658" },
  ]

  const wasteData = productionLogs.map((log) => ({
    date: log.date,
    waste: log.fabricLength * 0.05 * 42, // 5% waste
  }))

  const totalWaste = wasteData.reduce((sum, item) => sum + item.waste, 0)

  // Calculate current month income
  const currentMonthIncome = productionLogs
    .filter((log) => new Date(log.date).getMonth() === new Date().getMonth())
    .reduce(
      (total, log) => total + (getProductPrices()[log.productType as keyof ReturnType<typeof getProductPrices>] || 0),
      0,
    )

  // Check for alerts
  useEffect(() => {
    const newAlerts: string[] = []

    // Check yarn stock
    Object.entries(yarnStock).forEach(([yarn, amount]) => {
      if (amount < 200) {
        const yarnName = yarn === "cotton" ? t("cotton") : yarn === "silk" ? t("silk") : t("wool")
        newAlerts.push(`${t("lowStockWarning")}: ${yarnName} ${amount}g ${t("remaining")}`)
      }
    })

    // Check if no production logged today
    const today = new Date().toISOString().split("T")[0]
    const todayLogs = productionLogs.filter((log) => log.date === today)
    if (todayLogs.length === 0) {
      newAlerts.push(t("noProductionLoggedToday"))
    }

    setAlerts(newAlerts)
  }, [yarnStock, productionLogs, lang])

  // Handle production log submission
  const handleLogSubmit = () => {
    if (!newLog.orderId || !newLog.productType || !newLog.fabricLength || !newLog.timeTaken) {
      if (!newLog.orderId) {
        alert(t("noOrderId"))
        return
      }
      return
    }

    const fabricLength = Number.parseFloat(newLog.fabricLength)
    const timeTaken = Number.parseFloat(newLog.timeTaken)
    const efficiency = fabricLength / timeTaken

    const log: ProductionLog = {
      id: Date.now().toString(),
      date: new Date().toISOString().split("T")[0],
      orderId: newLog.orderId,
      productType: newLog.productType,
      fabricLength,
      timeTaken,
      efficiency,
      voiceNote: newLog.voiceNote,
    }

    setProductionLogs((prev) => [log, ...prev])

    // Auto-deduct yarn
    const yarnUsed = fabricLength * 42 // 42g per meter
    if (
      newLog.productType.includes("Cotton") ||
      newLog.productType.includes("பருத்தி") ||
      newLog.productType.includes("कपास")
    ) {
      setYarnStock((prev) => ({ ...prev, cotton: Math.max(0, prev.cotton - yarnUsed) }))
    } else if (
      newLog.productType.includes("Silk") ||
      newLog.productType.includes("பட்டு") ||
      newLog.productType.includes("रेशम")
    ) {
      setYarnStock((prev) => ({ ...prev, silk: Math.max(0, prev.silk - yarnUsed) }))
    }

    // Reset form
    setNewLog({ orderId: "", productType: "", fabricLength: "", timeTaken: "", voiceNote: "" })
  }

  // Simulate voice recording
  const handleVoiceRecord = () => {
    setIsRecording(true)
    setTimeout(() => {
      setIsRecording(false)
      setNewLog((prev) => ({ ...prev, voiceNote: "Voice note: Quality check completed, no issues found" }))
    }, 2000)
  }

  // Simulate QR scan for yarn
  const handleQRScan = () => {
    setYarnStock((prev) => ({
      ...prev,
      cotton: prev.cotton + 500,
      silk: prev.silk + 300,
    }))
  }

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (deliveryCountdown && deliveryCountdown > 0) {
      interval = setInterval(() => {
        setDeliveryCountdown((prev) => (prev ? prev - 1 : null))
      }, 60000) // Update every minute
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [deliveryCountdown])

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 sticky top-0 z-10">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Package className="w-6 h-6" />
              {t("appTitle")}
            </h1>
            <p className="text-blue-100 text-sm">{t("appSubtitle")}</p>
          </div>

          {/* Language Selector */}
          <div className="flex items-center gap-2">
            <span className="text-sm">🌐</span>
            <Select value={lang} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-24 h-8 bg-blue-500 border-blue-400 text-white text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="ta">தமிழ்</SelectItem>
                <SelectItem value="hi">हिंदी</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="p-4 space-y-2">
          {alerts.map((alert, index) => (
            <Alert key={index} className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">{alert}</AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-7 sticky top-16 z-10 bg-white border-b text-xs">
          <TabsTrigger value="production" className="text-xs">
            <Plus className="w-3 h-3 mr-1" />
            {t("log")}
          </TabsTrigger>
          <TabsTrigger value="inventory" className="text-xs">
            <Package className="w-3 h-3 mr-1" />
            Stock
          </TabsTrigger>
          <TabsTrigger value="orders" className="text-xs">
            <Package className="w-3 h-3 mr-1" />
            {t("orders")}
          </TabsTrigger>
          <TabsTrigger value="stock-ordering" className="text-xs">
            <Package className="w-3 h-3 mr-1" />
            {t("stockOrdering")}
          </TabsTrigger>
          <TabsTrigger value="database" className="text-xs">
            <Database className="w-3 h-3 mr-1" />
            {t("database")}
          </TabsTrigger>
          <TabsTrigger value="income" className="text-xs">
            <TrendingUp className="w-3 h-3 mr-1" />
            {t("income")}
          </TabsTrigger>
          <TabsTrigger value="analytics" className="text-xs">
            <BarChart3 className="w-3 h-3 mr-1" />
            {t("stats")}
          </TabsTrigger>
        </TabsList>

        {/* Production Logger */}
        <TabsContent value="production" className="p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                {t("logProduction")}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t("orderId")}</Label>
                  <Input
                    type="text"
                    value={newLog.orderId}
                    onChange={(e) => setNewLog((prev) => ({ ...prev, orderId: e.target.value }))}
                    placeholder={t("enterOrderId")}
                    required
                  />
                </div>
                <div>
                  <Label>{t("productType")}</Label>
                  <Select
                    value={newLog.productType}
                    onValueChange={(value) => setNewLog((prev) => ({ ...prev, productType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t("selectProduct")} />
                    </SelectTrigger>
                    <SelectContent>
                      {productTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>{t("productPrice")}</Label>
                  <div className="flex items-center h-10 px-3 py-2 border border-input bg-gray-50 rounded-md text-sm">
                    <span className="font-medium text-green-600">
                      ₹
                      {newLog.productType
                        ? getProductPrices()[
                            newLog.productType as keyof ReturnType<typeof getProductPrices>
                          ]?.toLocaleString() || "--"
                        : "--"}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t("fabricLength")}</Label>
                  <Input
                    type="number"
                    value={newLog.fabricLength}
                    onChange={(e) => setNewLog((prev) => ({ ...prev, fabricLength: e.target.value }))}
                    placeholder="6.0"
                  />
                </div>
                <div>
                  <Label>{t("timeTaken")}</Label>
                  <Input
                    type="number"
                    value={newLog.timeTaken}
                    onChange={(e) => setNewLog((prev) => ({ ...prev, timeTaken: e.target.value }))}
                    placeholder="8.0"
                  />
                </div>
              </div>

              <div>
                <Label>{t("voiceNote")}</Label>
                <div className="flex gap-2">
                  <Input
                    value={newLog.voiceNote}
                    onChange={(e) => setNewLog((prev) => ({ ...prev, voiceNote: e.target.value }))}
                    placeholder={t("addVoiceNote")}
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleVoiceRecord}
                    disabled={isRecording}
                    className={isRecording ? "bg-red-100 border-red-300" : ""}
                  >
                    <Mic className={`w-4 h-4 ${isRecording ? "text-red-600" : ""}`} />
                  </Button>
                </div>
                {isRecording && <p className="text-sm text-red-600 mt-1">{t("recording")}</p>}
              </div>

              <Button onClick={handleLogSubmit} className="w-full">
                {t("logProduction")}
              </Button>
            </CardContent>
          </Card>

          {/* Recent Logs */}
          <Card>
            <CardHeader>
              <CardTitle>{t("recentProduction")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {productionLogs.slice(0, 3).map((log) => (
                  <div key={log.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{log.productType}</p>
                      <p className="text-sm text-gray-600">
                        {log.fabricLength}m in {log.timeTaken}hrs
                      </p>
                      <p className="text-xs text-blue-600">Order: {log.orderId}</p>
                      <p className="text-xs text-gray-500">{log.date}</p>
                    </div>
                    <Badge variant="secondary">{log.efficiency.toFixed(2)} m/hr</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Weekly Chart */}
          <Card>
            <CardHeader>
              <CardTitle>{t("weeklyProduction")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="meters" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Inventory Manager */}
        <TabsContent value="inventory" className="p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                {t("yarnInventory")}
              </CardTitle>
              <CardDescription>{t("currentStockLevels")}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(yarnStock).map(([yarn, amount]) => {
                const yarnName = yarn === "cotton" ? t("cotton") : yarn === "silk" ? t("silk") : t("wool")
                return (
                  <div key={yarn} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="capitalize font-medium">{yarnName}</span>
                      <span className={amount < 200 ? "text-red-600 font-bold" : ""}>{amount}g</span>
                    </div>
                    <Progress value={(amount / 2000) * 100} className="h-2" />
                    {amount < 200 && <p className="text-sm text-red-600">⚠️ {t("lowStockAlert")}</p>}
                  </div>
                )
              })}

              <Button onClick={handleQRScan} className="w-full mt-4 bg-transparent" variant="outline">
                <QrCode className="w-4 h-4 mr-2" />
                {t("scanQRToAddStock")}
              </Button>
            </CardContent>
          </Card>

          {/* Waste Estimator */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Recycle className="w-5 h-5" />
                {t("fabricWasteTracker")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span>{t("totalWasteThisWeek")}</span>
                  <Badge variant="outline">{totalWaste.toFixed(0)}g</Badge>
                </div>

                <div className="bg-green-50 p-3 rounded-lg">
                  <h4 className="font-medium text-green-800 mb-2">{t("reuseSuggestions")}</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• {t("useForPouches")}</li>
                    <li>• {t("createPatches")}</li>
                    <li>• {t("makeCleaningCloths")}</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Section */}
        <TabsContent value="orders" className="p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                {t("orders")}
              </CardTitle>
              <CardDescription>{t("selectItems")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockOrderGroups.map((orderGroup) => (
                  <div key={orderGroup.orderId} className="border rounded-lg overflow-hidden">
                    {/* Order Group Header */}
                    <div
                      className="bg-blue-50 p-4 cursor-pointer hover:bg-blue-100 transition-colors"
                      onClick={() => toggleOrderExpansion(orderGroup.orderId)}
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                            📦
                          </div>
                          <div>
                            <h3 className="font-semibold text-blue-900">
                              {t("orderGroup")}: {orderGroup.orderId}
                            </h3>
                            <p className="text-sm text-blue-700">{orderGroup.items.length} items available</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getTotalSelectedItemsForOrder(orderGroup.orderId) > 0 && (
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {getTotalSelectedItemsForOrder(orderGroup.orderId)} selected
                            </Badge>
                          )}
                          <div
                            className={`transform transition-transform ${expandedOrders[orderGroup.orderId] ? "rotate-180" : ""}`}
                          >
                            ▼
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Order Group Items */}
                    {expandedOrders[orderGroup.orderId] && (
                      <div className="p-4 space-y-3 bg-white">
                        <div className="space-y-3 max-h-64 overflow-y-auto">
                          {orderGroup.items.map((item) => (
                            <div
                              key={item.id}
                              className="flex items-center gap-4 p-3 border rounded-lg hover:bg-gray-50"
                            >
                              <input
                                type="checkbox"
                                checked={selectedOrderItems[orderGroup.orderId]?.[item.id]?.checked || false}
                                onChange={(e) =>
                                  updateOrderSelection(orderGroup.orderId, item.id, { checked: e.target.checked })
                                }
                                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                              />

                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium text-sm">{item.name}</h4>
                                <p className="text-xs text-gray-600 truncate">{item.description}</p>
                                <p className="text-sm font-semibold text-green-600">₹{item.price.toLocaleString()}</p>
                              </div>

                              <div className="flex items-center gap-2">
                                <Label className="text-xs">{t("quantity")}:</Label>
                                <Input
                                  type="number"
                                  min="1"
                                  max="99"
                                  value={selectedOrderItems[orderGroup.orderId]?.[item.id]?.quantity || 1}
                                  onChange={(e) =>
                                    updateOrderSelection(orderGroup.orderId, item.id, {
                                      quantity: Number.parseInt(e.target.value) || 1,
                                    })
                                  }
                                  className="w-16 h-8 text-xs"
                                  disabled={!selectedOrderItems[orderGroup.orderId]?.[item.id]?.checked}
                                />
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Order Group Submit Button */}
                        <div className="pt-3 border-t">
                          {getTotalSelectedItemsForOrder(orderGroup.orderId) > 0 && (
                            <div className="mb-3 p-3 bg-blue-50 rounded-lg">
                              <p className="text-sm text-blue-800">
                                Selected {getTotalSelectedItemsForOrder(orderGroup.orderId)} item
                                {getTotalSelectedItemsForOrder(orderGroup.orderId) > 1 ? "s" : ""} from{" "}
                                {orderGroup.orderId}
                              </p>
                            </div>
                          )}

                          <Button
                            onClick={() => handleOrderSubmit(orderGroup.orderId)}
                            disabled={
                              getTotalSelectedItemsForOrder(orderGroup.orderId) === 0 ||
                              isSubmittingOrders[orderGroup.orderId]
                            }
                            className="w-full"
                          >
                            {isSubmittingOrders[orderGroup.orderId] ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                {t("submitting")}
                              </>
                            ) : (
                              `${t("submitOrder")} ${orderGroup.orderId}`
                            )}
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Stock Ordering Section */}
        <TabsContent value="stock-ordering" className="p-4 space-y-4">
          {/* Stock Alert Banner */}
          {mockStockItems.filter((item) => item.status === "outOfStock" || item.status === "lowStock").length > 0 && (
            <Alert className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                {t("stockAlert")}: {mockStockItems.filter((item) => item.status === "outOfStock").length} items out of
                stock, {mockStockItems.filter((item) => item.status === "lowStock").length} items low stock
              </AlertDescription>
            </Alert>
          )}

          {/* Delivery Countdown */}
          {deliveryCountdown && deliveryCountdown > 0 && (
            <Card className="bg-green-50 border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-green-800 font-medium">
                    {t("deliveryEta")}: {deliveryCountdown} {t("minutes")}
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                {t("restockMaterials")}
              </CardTitle>
              <CardDescription>Select materials to restock from 5 categories</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {stockOrders.map((order, index) => {
                const categoryKey = order.category.replace(" ", "") as keyof typeof stockCategories
                const categoryItems = stockCategories[categoryKey] || []
                const translatedCategory = t(
                  order.category.toLowerCase().replace(" ", "") as keyof typeof translations.en,
                )

                return (
                  <div key={order.category} className="space-y-3 p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={order.selected}
                        onChange={(e) => updateStockOrder(order.category, { selected: e.target.checked })}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                      <Label className="font-medium text-base">{translatedCategory}</Label>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 ml-7">
                      <div>
                        <Label className="text-sm">{t("selectItem")}</Label>
                        <Select
                          value={order.item}
                          onValueChange={(value) => updateStockOrder(order.category, { item: value })}
                          disabled={!order.selected}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={t("selectItem")} />
                          </SelectTrigger>
                          <SelectContent>
                            {categoryItems.map((item) => {
                              const translatedItem = t(
                                item.toLowerCase().replace(" ", "") as keyof typeof translations.en,
                              )
                              const itemPrice = itemPrices[item]
                              const status = getItemStatus(order.category, item)
                              return (
                                <SelectItem key={item} value={item}>
                                  <div className="flex items-center justify-between w-full">
                                    <div className="flex items-center gap-2">
                                      <span>{translatedItem}</span>
                                      {status === "outOfStock" && (
                                        <Badge variant="destructive" className="text-xs">
                                          {t("outOfStock")}
                                        </Badge>
                                      )}
                                      {status === "lowStock" && (
                                        <Badge variant="outline" className="text-xs text-orange-600">
                                          {t("lowStock")}
                                        </Badge>
                                      )}
                                    </div>
                                    {itemPrice && (
                                      <span className="text-green-600 font-medium text-sm ml-2">
                                        ₹{itemPrice.price}/{getItemUnit(order.category, item)}
                                      </span>
                                    )}
                                  </div>
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label className="text-sm">{t("quantity")}</Label>
                        <Input
                          type="number"
                          min="1"
                          max="999"
                          value={order.quantity}
                          onChange={(e) =>
                            updateStockOrder(order.category, { quantity: Number.parseInt(e.target.value) || 1 })
                          }
                          disabled={!order.selected || !order.item}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <Label className="text-sm">{t("price")}</Label>
                        <div className="flex items-center h-10 px-3 py-2 border border-input bg-gray-50 rounded-md text-sm">
                          {order.item ? (
                            <span className="font-medium text-green-600">
                              ₹{(getItemPrice(order.category, order.item) * order.quantity).toLocaleString()} (
                              {order.quantity} {getItemUnit(order.category, order.item)}
                              {order.quantity > 1 ? "s" : ""})
                            </span>
                          ) : (
                            <span className="text-gray-400">--</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {order.selected && order.item && (
                      <div className="ml-7 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800">
                          Total: ₹{(getItemPrice(order.category, order.item) * order.quantity).toLocaleString()} (
                          {order.quantity} {getItemUnit(order.category, order.item)}
                          {order.quantity > 1 ? "s" : ""})
                        </p>
                      </div>
                    )}
                  </div>
                )
              })}

              {getSelectedStockCount() > 0 && (
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800 mb-2">
                    Selected {getSelectedStockCount()} categor{getSelectedStockCount() > 1 ? "ies" : "y"} for restocking
                  </p>
                  <p className="text-lg font-semibold text-green-900">
                    Total Order Value: ₹
                    {stockOrders
                      .filter((order) => order.selected && order.item)
                      .reduce((total, order) => total + getItemPrice(order.category, order.item) * order.quantity, 0)
                      .toLocaleString()}
                  </p>
                </div>
              )}

              <Button
                onClick={handleStockOrderSubmit}
                disabled={getSelectedStockCount() === 0 || isSubmittingStockOrder}
                className="w-full"
                size="lg"
              >
                {isSubmittingStockOrder ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    {t("submittingStockOrder")}
                  </>
                ) : (
                  t("submitStockOrder")
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Past Orders */}
          {pastStockOrders.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5" />
                  {t("viewPastOrders")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pastStockOrders.slice(0, 3).map((order) => (
                    <div key={order.id} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <p className="font-medium">Order #{order.id.toString().slice(-4)}</p>
                        <Badge variant="outline">{order.status}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">
                        {order.items.length} items • {new Date(order.timestamp).toLocaleDateString()}
                      </p>
                      <div className="text-xs text-gray-500">
                        {order.items.map((item: any, idx: number) => (
                          <span key={idx}>
                            {item.item} ({item.quantity}){idx < order.items.length - 1 ? ", " : ""}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Product Management / Database Section */}
        <TabsContent value="database" className="p-4 space-y-4">
          {/* Add Product Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                {t("addNewProduct")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={addProduct} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>{t("productName")}</Label>
                    <Input
                      type="text"
                      value={newProduct.name}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder={t("enterProductName")}
                      required
                    />
                  </div>
                  <div>
                    <Label>{t("productCategory")}</Label>
                    <Select
                      value={newProduct.type}
                      onValueChange={(value) => setNewProduct((prev) => ({ ...prev, type: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={t("selectCategory")} />
                      </SelectTrigger>
                      <SelectContent>
                        {productCategories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>{t("price")} (₹)</Label>
                    <Input
                      type="number"
                      value={newProduct.price}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, price: e.target.value }))}
                      placeholder={t("enterPrice")}
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>
                  <div>
                    <Label>{t("stockQuantity")}</Label>
                    <Input
                      type="number"
                      value={newProduct.stock}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, stock: e.target.value }))}
                      placeholder={t("enterStock")}
                      min="0"
                      required
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  {t("addProduct")}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Product List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                {t("productList")}
              </CardTitle>
              <CardDescription>Total Products: {products.length}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2 font-medium">{t("name")}</th>
                      <th className="text-left p-2 font-medium">{t("type")}</th>
                      <th className="text-left p-2 font-medium">{t("price")}</th>
                      <th className="text-left p-2 font-medium">{t("stockRemaining")}</th>
                      <th className="text-left p-2 font-medium">{t("actions")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{product.name}</td>
                        <td className="p-2">
                          <Badge variant="outline">{product.type}</Badge>
                        </td>
                        <td className="p-2 text-green-600 font-semibold">₹{product.price.toLocaleString()}</td>
                        <td className="p-2">
                          <span className={product.stock < 10 ? "text-red-600 font-bold" : ""}>{product.stock}</span>
                        </td>
                        <td className="p-2">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => removeProduct(product.id)}
                            className="h-8"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            {t("remove")}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {products.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Database className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No products in database</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Income & Goals */}
        <TabsContent value="income" className="p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                {t("monthlyGoal")}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-green-600">₹{currentMonthIncome.toLocaleString()}</p>
                <p className="text-gray-600">
                  {t("of")} ₹{monthlyGoal.toLocaleString()} {t("goal")}
                </p>
              </div>

              <Progress value={(currentMonthIncome / monthlyGoal) * 100} className="h-3" />

              <div className="flex justify-between text-sm text-gray-600">
                <span>
                  {((currentMonthIncome / monthlyGoal) * 100).toFixed(1)}% {t("complete")}
                </span>
                <span>
                  ₹{(monthlyGoal - currentMonthIncome).toLocaleString()} {t("remaining")}
                </span>
              </div>

              <div className="mt-4">
                <Label>{t("updateMonthlyGoal")}</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    type="number"
                    value={monthlyGoal}
                    onChange={(e) => setMonthlyGoal(Number(e.target.value))}
                    className="flex-1"
                  />
                  <Button variant="outline">{t("update")}</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Orders & Calendar */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="w-5 h-5" />
                {t("upcomingOrders")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {orders.map((order) => (
                  <div key={order.id} className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{order.product}</p>
                      <p className="text-sm text-gray-600">{order.customer}</p>
                      <p className="text-xs text-gray-500">
                        {t("due")}: {order.deadline}
                      </p>
                    </div>
                    <Badge variant={order.status === "completed" ? "default" : "secondary"}>
                      {t(order.status as keyof typeof translations.en)}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                {t("weeklyLeaderboard")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {weavers
                  .sort((a, b) => b.weeklyOutput - a.weeklyOutput)
                  .slice(0, 3)
                  .map((weaver, index) => (
                    <div key={weaver.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{weaver.name}</p>
                        <p className="text-sm text-gray-600">
                          {weaver.weeklyOutput}m {t("thisWeek")}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        {weaver.badges.map((badge) => (
                          <Badge key={badge} variant="outline" className="text-xs">
                            {badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics" className="p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{t("yarnUsageDistribution")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={yarnUsageData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {yarnUsageData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("efficiencyMetrics")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">
                    {(productionLogs.reduce((sum, log) => sum + log.efficiency, 0) / productionLogs.length).toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-600">{t("avgEfficiency")}</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">
                    {productionLogs.reduce((sum, log) => sum + log.fabricLength, 0)}
                  </p>
                  <p className="text-sm text-gray-600">{t("totalMeters")}</p>
                </div>
              </div>

              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <p className="text-2xl font-bold text-purple-600">
                  ₹{(currentMonthIncome / new Date().getDate()).toFixed(0)}
                </p>
                <p className="text-sm text-gray-600">{t("dailyAverageIncome")}</p>
              </div>
            </CardContent>
          </Card>

          {/* Cluster View */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                {t("clusterOverview")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {weavers.map((weaver) => (
                  <div key={weaver.id} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{weaver.name}</h4>
                      <Badge variant="outline">{weaver.weeklyOutput}m/week</Badge>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600 mb-2">
                      <span>
                        {t("stock")}: {weaver.stockLeft}g
                      </span>
                      <span className={weaver.stockLeft < 300 ? "text-red-600" : "text-green-600"}>
                        {weaver.stockLeft < 300 ? t("lowStock") : t("goodStock")}
                      </span>
                    </div>
                    <div className="flex gap-1">
                      {weaver.badges.map((badge) => (
                        <Badge key={badge} variant="secondary" className="text-xs">
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
